/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calcbasica.migueltumax;

/**
 *
 * @author LABORATORIO
 */
public class CalcBasica30MiguelTumax {

    public static void main(String[] args) {
        jfrmCalc hola = new jfrmCalc();
        hola.setVisible(true);
    }
}
